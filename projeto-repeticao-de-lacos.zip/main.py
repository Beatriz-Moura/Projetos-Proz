andar = 21
for i in range(20,0,-1):
    andar = andar - 1
    if (andar == 13):
        continue
    print (andar,"° andar ")
    
andar = 21  
while (andar > 1):
    andar = andar - 1
    if (andar == 13):
      continue  
    print (andar, "° andar ")